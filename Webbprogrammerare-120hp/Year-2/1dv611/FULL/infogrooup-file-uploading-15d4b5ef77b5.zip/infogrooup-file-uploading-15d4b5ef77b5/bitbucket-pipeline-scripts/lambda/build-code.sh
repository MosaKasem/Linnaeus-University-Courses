#!/bin/bash

echo "Zipping code"
zip -r ./build/lambda.zip * 

