#!/bin/bash

echo "Installing dependencies"
npm install --only=prod

